package com.poramordemuitos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoramordemuitosApplicationTests {

	@Test
	void contextLoads() {
	}

}
